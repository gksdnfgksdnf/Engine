using UnityEngine;

public class Climb : MonoBehaviour
{
}
