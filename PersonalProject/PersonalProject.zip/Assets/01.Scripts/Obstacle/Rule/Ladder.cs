
using UnityEngine;

public class Ladder : MonoBehaviour
{
}
