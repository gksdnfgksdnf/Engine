using UnityEngine;
using System;
using System.Collections.Generic;

public class Is : MonoBehaviour
{
    [SerializeField] private LayerMask _whatisTarget;
    [SerializeField] private int _range;

    [SerializeField] private List<Type> addedComponents = new List<Type>(); // �߰��� ������Ʈ�� �����ϱ� ���� ����Ʈ

    public void DrawRay(Vector3 dir, GameObject[] gameObj)
    {
        bool isHit = Physics.Raycast(transform.position, Vector3.back, out RaycastHit hit, _range, _whatisTarget);

        if (isHit)
        {
            // ������ �۾��� ���������� �ٷ� ����
            if (addedComponents.Count > 0)
            {
                return;
            }

            //�Ӽ� �߰�
            if (hit.collider.TryGetComponent(out You you))
                addedComponents.Add(typeof(Movement));
            if (hit.collider.TryGetComponent(out Push push))
                addedComponents.Add(typeof(Obstacle));
            if (hit.collider.TryGetComponent(out Win win))
                addedComponents.Add(typeof(Win));
            if (hit.collider.TryGetComponent(out Death death))
                addedComponents.Add(typeof(Skul));
            if (hit.collider.TryGetComponent(out Open open))
                addedComponents.Add(typeof(Key));
            if (hit.collider.TryGetComponent(out Stop stop))
                addedComponents.Add(typeof(Wall));
            if (hit.collider.TryGetComponent(out Lock l))
                addedComponents.Add(typeof(Chest));

            if (hit.collider.TryGetComponent(out Subject s))
            {
                if (hit.collider.gameObject.CompareTag("Flag"))
                {
                    Debug.Log("Flag Subject �߰�");
                    addedComponents.Add(typeof(Win));
                }
                if (hit.collider.gameObject.CompareTag("Baba"))
                {
                    Debug.Log("Baba Subject �߰�");
                    addedComponents.Add(typeof(Movement));
                }
                if (hit.collider.gameObject.CompareTag("Rock"))
                {
                    Debug.Log("Rock Subject �߰�");
                    addedComponents.Add(typeof(Obstacle));
                }
            }

            foreach (GameObject obj in gameObj)
            {
                DestroyComponent(obj);
                foreach (Type componentType in addedComponents)
                {
                    Debug.Log($"{componentType} �߰�");
                    obj.AddComponent(componentType);
                }
            }
        }
        else
        {
            foreach (GameObject obj in gameObj)
            {
                DestroyComponent(obj);
                Debug.Log(obj + "����");
            }
        }
    }

    public void DestroyComponent(GameObject obj)
    {
        for (int i = addedComponents.Count - 1; i >= 0; i--)
        {
            Type componentType = addedComponents[i];
            MonoBehaviour component = obj.GetComponent(componentType) as MonoBehaviour;
            if (component != null)
            {
                Debug.Log($"{componentType} ����");
                Destroy(component);
                addedComponents.RemoveAt(i);
            }
        }
    }
}